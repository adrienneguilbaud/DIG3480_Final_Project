﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ADGUDogRun : MonoBehaviour {

    public float speed;
    public bool amIPet;

    public AudioSource barkSource;
    private bool secondBark = false;
    public Animator anim;

    public ParticleSystem petParticle;
    private bool particleOn;

	// Use this for initialization
	void Start () {
        speed = Random.Range(0.1f, 0.25f);
        amIPet = false;
        particleOn = false;
	}
	
	// Update is called once per frame
	void Update () {
        if (!amIPet)
        {
            transform.Translate(new Vector3(speed, 0.0f, 0.0f));
        }
        else
        {
            if (!secondBark)
            {
                barkSource.Play();
                secondBark = true;
            }
            if (!particleOn)
            {
                Instantiate(petParticle, transform);
                particleOn = true;
            }
            StartCoroutine(WaitForPets());
            this.GetComponent<SpriteRenderer>().flipX = false;
            transform.Translate(new Vector3(-speed, 0.0f, 0.0f));
        }
	}

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            Debug.Log("that's a player");
            if (collision.gameObject.GetComponent<ADGUPlayerController>().pet)
                Debug.Log("i've been pet!");
        }
    }

    IEnumerator WaitForPets()
    {
        yield return new WaitForSeconds(50f);
    }
}
