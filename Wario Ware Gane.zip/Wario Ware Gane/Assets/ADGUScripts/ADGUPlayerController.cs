﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class ADGUPlayerController : MonoBehaviour {

    public float speed;
    public Animator animator;
    public bool pet;
    public Text countText;
    public TextMeshProUGUI winText;
    //public ParticleSystem petParticle;
    public TextMeshProUGUI startText;

    private Rigidbody2D rb2d;
    private int count;
    private float timer;
    private bool gameWon;
    private bool gameLost;

	// Use this for initialization
	void Start ()
    {
        rb2d = GetComponent<Rigidbody2D>();
        count = 0;
        winText.text = "";
        SetCountText();
        gameWon = false;
        gameLost = false;
        StartCoroutine(DeactivateStartText(2));
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (Input.GetButton("Pet") || Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.U)
            || Input.GetKey(KeyCode.I) || Input.GetKey(KeyCode.O) || Input.GetKey(KeyCode.J) 
            || Input.GetKey(KeyCode.K) || Input.GetKey(KeyCode.L))
        {
            pet = true;
            animator.SetBool("isPetting", true);
            animator.SetBool("isRunning", false);
        }
            else
        {
            pet = false;
            animator.SetBool("isPetting", false);
        }

        if (Input.GetKey("escape"))
            Application.Quit();
    }

    void FixedUpdate()
    {
        if (!pet)
        {
            float moveHorizontal = Input.GetAxis("Horizontal");
            float moveVertical = Input.GetAxis("Vertical");

            if (moveHorizontal > 0)
            {
                animator.SetBool("RunRight", true);
                animator.SetBool("RunLeft", false);
            }
            else if (moveHorizontal < 0)
            {
                animator.SetBool("RunLeft", true);
                animator.SetBool("RunRight", false);
            } 
            else
            {
                animator.SetBool("RunRight", false);
                animator.SetBool("RunLeft", false);
            }

            if (moveVertical > 0)
            {
                animator.SetBool("RunUp", true);
                animator.SetBool("RunDown", false);
            }
            else if (moveVertical < 0)
            {
                animator.SetBool("RunDown", true);
                animator.SetBool("RunUp", false);
            }
            else
            {
                animator.SetBool("RunDown", false);
                animator.SetBool("RunUp", false);
            }

           /* if (moveHorizontal == 0 && moveVertical == 0)
            {
                animator.SetBool("")
            }*/

            Vector3 movement = new Vector3(moveHorizontal, moveVertical, 0);

            transform.Translate(moveHorizontal * speed, moveVertical * speed, 0);
        }

        timer = timer + Time.deltaTime;

        if (timer >= 10 && gameWon == false)
        {
            gameLost = true;
            winText.text = "You Lose! :(";
            StartCoroutine(ByeAfterDelay(2));
        }
    }

    IEnumerator ByeAfterDelay(float time)
    {
        yield return new WaitForSeconds(time);

        // Code to execute after the delay

        GameLoader.gameOn = false;
    }

    IEnumerator DeactivateStartText(float time)
    {
        yield return new WaitForSeconds(time);
        startText.text = "";
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Pet"))
        {
            if (pet)
            {
                //Instantiate(petParticle, transform, true);
                count = count + 1;
                GameLoader.AddScore(1);
                SetCountText();
                other.gameObject.GetComponent<ADGUDogRun>().amIPet = true;
            }
        }
    }

    void SetCountText()
    {
        countText.text = "Doggos pet: " + count.ToString();
        if (count >= 10 && gameLost == false)
        {
            gameWon = true;
            winText.text = "You Win!";
            StartCoroutine(ByeAfterDelay(2));
        }
    }
}
