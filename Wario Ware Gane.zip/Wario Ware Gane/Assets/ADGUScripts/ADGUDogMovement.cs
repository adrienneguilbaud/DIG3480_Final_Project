﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ADGUDogMovement : MonoBehaviour {

    //public GameObject doggoBrown;
    //public GameObject doggoGrey;
    public GameObject[] doggos;
    private int dogPickIndex = 1;
    public Vector3 spawnValues;
    public int doggoCount;
    public float spawnWait;
    public float startWait;
    public float waveWait;
    public float lifetime;

    IEnumerator SpawnWaves()
    {
        yield return new WaitForSeconds(startWait);
        while (true)
        {
            for (int i = 0; i < doggoCount; i++)
            {
                Vector3 spawnPosition = new Vector3(spawnValues.x,
                                                    Random.Range(-spawnValues.y, spawnValues.y), 
                                                    0f);
                Quaternion spawnRotation = Quaternion.identity;

                dogPickIndex = Random.Range(0, 2);

                Instantiate(doggos[dogPickIndex], spawnPosition, spawnRotation);
                yield return new WaitForSeconds(spawnWait);
            }
            yield return new WaitForSeconds(waveWait);
        }
    }
    
    void Start () {
        StartCoroutine(SpawnWaves());
    }
}
